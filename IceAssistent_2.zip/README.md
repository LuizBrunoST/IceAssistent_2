# estensão ICE Assistent

**LOG**

**03/10/2021**
* mod manifest.json
* mod ice/ice.js

**29/09/2021**
* mod ice/ice.js

**26/09/2021**
* mod index.html

**24/09/2021**
* del ice/comandos.js

**23/09/2021**
* add ice/comandos.js
* mod ice/ice.js
* mod manifest.json

**22/09/2021**
* mod ice/ice.js

**19/09/2021**
* add manifest.json
* add css/*
* add img/*
* add readme.md
* add ice/ice.js
* add background.js
* add ice/popup.js
